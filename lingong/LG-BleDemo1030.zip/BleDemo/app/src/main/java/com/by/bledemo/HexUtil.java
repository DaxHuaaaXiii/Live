package com.by.bledemo;

public class HexUtil {
    public HexUtil(){

    }
    private static byte charToByte(char c) {
        return (byte)"0123456789ABCDEF".indexOf(c);
    }

    public static byte[] hex2Byte(String hex) {
        if (hex == null) {
            return null;
        } else {
            hex = hex.replaceAll("\\s+", "");
            if (hex.length() % 2 != 0) {
                throw new RuntimeException("Hex string is illegal");
            } else {
                hex = hex.toUpperCase();
                int length = hex.length() / 2;
                char[] hexChars = hex.toCharArray();
                byte[] result = new byte[length];

                for(int i = 0; i < length; ++i) {
                    int pos = i * 2;
                    result[i] = (byte)(charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
                }

                return result;
            }
        }
    }

    public static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        byte[] var2 = bytes;
        int var3 = bytes.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            byte aByte = var2[var4];
            String hex = Integer.toHexString(aByte & 255);
            if (hex.length() < 2) {
                sb.append(0);
            }

            sb.append(hex);
        }

        return sb.toString();
    }

    public static String bytesToHex(byte head) {
        StringBuilder sb = new StringBuilder();
        String hex = Integer.toHexString(head & 255);
        if (hex.length() < 2) {
            sb.append(0);
        }

        return sb.toString();
    }

    public static byte[] hexStringToBytes(String hexString) {
        if (hexString == null || hexString.equals("")) {
            return null;
        }
        hexString = hexString.toUpperCase();
        int length = hexString.length() / 2;
        char[] hexChars = hexString.toCharArray();
        byte[] d = new byte[length];
        for (int i = 0; i < length; i++) {
            int pos = i * 2;
            d[i] = (byte) (charToByte(hexChars[pos]) << 4 | charToByte(hexChars[pos + 1]));
        }
        return d;
    }

}
