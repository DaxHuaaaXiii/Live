# BleDemo

#扫描与连接

[Android BLE低功耗蓝牙开发极简系列（一）之扫描与连接](http://www.jianshu.com/p/87ed84431ec1)

#读取和写入

[Android BLE低功耗蓝牙开发极简系列（二）之读写操作](http://www.jianshu.com/p/046c1f5a7163)
