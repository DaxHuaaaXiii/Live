package com.example.showapplist;

import android.content.Intent;
import android.graphics.drawable.Drawable;

public class AppInfo {
	public String pkgName;
	public String appName;
	public Drawable appIcon;
	public Intent appIntent;
}
